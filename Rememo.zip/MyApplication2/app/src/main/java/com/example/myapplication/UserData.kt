package com.example.myapplication

import java.io.Serializable

class UserData (
    val id: Int,
    val username: String?
) : Serializable