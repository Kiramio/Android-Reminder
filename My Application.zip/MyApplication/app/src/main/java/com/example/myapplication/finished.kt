package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class finished : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finished)
    }

    /*
    fun onRecyclerInteraction() {

        loadDetailFragment()
    }

    private fun loadDetailFragment(){

    }
     */

}
